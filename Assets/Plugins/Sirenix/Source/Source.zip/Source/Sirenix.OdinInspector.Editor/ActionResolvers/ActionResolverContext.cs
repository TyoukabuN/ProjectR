#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="ActionResolverContext.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor.ActionResolvers
{
#pragma warning disable

    using System;

    public struct ActionResolverContext
    {
        public InspectorProperty Property;
        public string ResolvedString;
        public string ErrorMessage;
        public NamedValues NamedValues;
        public bool SyncRefParametersWithNamedValues;
        public bool ErrorMessageIsDueToException;

        private InspectorProperty propertyUsedForContextProperty;
        private InspectorProperty contextProperty;

        public Type ParentType { get { return this.ContextProperty.ValueEntry.TypeOfValue; } }

        public InspectorProperty ContextProperty
        {
            get
            {
                if (this.contextProperty == null || this.propertyUsedForContextProperty != this.Property)
                {
                    this.propertyUsedForContextProperty = this.Property;
                    var nearestBackingMemberProperty = this.Property;

                    while (nearestBackingMemberProperty != null && !nearestBackingMemberProperty.Info.HasBackingMembers)
                    {
                        nearestBackingMemberProperty = nearestBackingMemberProperty.ParentValueProperty;
                    }

                    if (nearestBackingMemberProperty == null)
                    {
                        this.contextProperty = this.Property.Tree.RootProperty;
                    }
                    else
                    {
                        this.contextProperty = nearestBackingMemberProperty.ParentValueProperty ?? this.Property.Tree.RootProperty;
                    }
                }

                return this.contextProperty;
            }
        }

        public object GetParentValue(int selectionIndex)
        {
            return this.ContextProperty.ValueEntry.WeakValues[selectionIndex];
        }

        public void SetParentValue(int selectionIndex, object value)
        {
            this.ContextProperty.ValueEntry.WeakValues[selectionIndex] = value;
        }

        private static readonly NamedValueGetter PropertyGetter = (ref ActionResolverContext context, int selectionIndex) => context.Property;
        private static readonly NamedValueGetter ValueGetter = (ref ActionResolverContext context, int selectionIndex) => context.Property.ValueEntry.WeakValues[selectionIndex];

        public void AddDefaultContextValues()
        {
            this.NamedValues.Add("property", typeof(InspectorProperty), PropertyGetter);

            if (this.Property.ValueEntry != null)
            {
                this.NamedValues.Add("value", this.Property.ValueEntry.BaseValueType, ValueGetter);
            }
        }
    }
}
#endif