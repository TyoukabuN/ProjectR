#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="ActionResolver.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor.ActionResolvers
{
#pragma warning disable

    using Sirenix.Utilities.Editor;
    using System;
    using System.Text;

    public sealed class ActionResolver
    {
        private static readonly StringBuilder SB = new StringBuilder();

        public ActionResolverContext Context;
        public ResolvedAction Action;

        public string ErrorMessage { get { return this.Context.ErrorMessage; } }
        public bool HasError { get { return this.Context.ErrorMessage != null; } }

        public void DrawError()
        {
            if (this.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(this.ErrorMessage);
            }
        }

        public void DoAction(int selectionIndex = 0)
        {
            if (selectionIndex < 0 || selectionIndex >= this.Context.Property.ParentValues.Count)
            {
                throw new IndexOutOfRangeException();
            }

            this.Context.NamedValues.UpdateValues(ref this.Context, selectionIndex);

            try
            {
                this.Action(ref this.Context, selectionIndex);

                if (this.Context.ErrorMessage != null && this.Context.ErrorMessageIsDueToException)
                {
                    this.Context.ErrorMessage = null;
                    this.Context.ErrorMessageIsDueToException = false;
                }
            }
            catch (Exception ex)
            {
                while (ex is System.Reflection.TargetInvocationException)
                {
                    ex = ex.InnerException;
                }

                //if (Event.current == null) throw ex;

                //if (Event.current.type == EventType.Repaint)
                {
                    this.Context.ErrorMessage = "Action execution for '" + this.Context.ResolvedString + "' threw an exception: " + ex.Message + "\n\n" + ex.StackTrace;
                    this.Context.ErrorMessageIsDueToException = true;
                }
            }
        }

        public void DoActionForAllSelectionIndices()
        {
            var count = this.Context.Property.ParentValues.Count;

            for (int i = 0; i < count; i++)
            {
                this.DoAction(i);
            }
        }

        public static ActionResolver Get(InspectorProperty property, string resolvedString)
        {
            return ActionResolverCreator.GetResolver(property, resolvedString);
        }

        public static ActionResolver Get(InspectorProperty property, string resolvedString, params NamedValue[] namedArgs)
        {
            return ActionResolverCreator.GetResolver(property, resolvedString, namedArgs);
        }

        public static string GetCombinedErrors(ActionResolver r1 = null, ActionResolver r2 = null, ActionResolver r3 = null, ActionResolver r4 = null, ActionResolver r5 = null, ActionResolver r6 = null, ActionResolver r7 = null, ActionResolver r8 = null)
        {
            return GetCombinedErrors(r1, r2, r3, r4, r5, r6, r7, r8, null);
        }

        public static string GetCombinedErrors(ActionResolver r1, ActionResolver r2, ActionResolver r3, ActionResolver r4, ActionResolver r5, ActionResolver r6, ActionResolver r7, ActionResolver r8, params ActionResolver[] remainder)
        {
            SB.Length = 0;

            if (r1 != null) { if (r1.ErrorMessage != null) { if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); } SB.Append(r1.ErrorMessage); } }
            if (r2 != null) { if (r2.ErrorMessage != null) { if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); } SB.Append(r2.ErrorMessage); } }
            if (r3 != null) { if (r3.ErrorMessage != null) { if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); } SB.Append(r3.ErrorMessage); } }
            if (r4 != null) { if (r4.ErrorMessage != null) { if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); } SB.Append(r4.ErrorMessage); } }
            if (r5 != null) { if (r5.ErrorMessage != null) { if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); } SB.Append(r5.ErrorMessage); } }
            if (r6 != null) { if (r6.ErrorMessage != null) { if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); } SB.Append(r6.ErrorMessage); } }
            if (r7 != null) { if (r7.ErrorMessage != null) { if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); } SB.Append(r7.ErrorMessage); } }
            if (r8 != null) { if (r8.ErrorMessage != null) { if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); } SB.Append(r8.ErrorMessage); } }

            if (remainder != null)
            {
                for (int i = 0; i < remainder.Length; i++)
                {
                    if (remainder[i] != null && remainder[i].HasError)
                    {
                        if (SB.Length > 0) { SB.AppendLine(); SB.AppendLine(); SB.AppendLine("And,"); SB.AppendLine(); }
                        SB.Append(remainder[i].ErrorMessage);
                    }
                }
            }

            return SB.Length == 0 ? null : SB.ToString();
        }

        public static void DrawErrors(ActionResolver r1 = null, ActionResolver r2 = null, ActionResolver r3 = null, ActionResolver r4 = null, ActionResolver r5 = null, ActionResolver r6 = null, ActionResolver r7 = null, ActionResolver r8 = null)
        {
            DrawErrors(r1, r2, r3, r4, r5, r6, r7, r8, null);
        }

        public static void DrawErrors(ActionResolver r1 = null, ActionResolver r2 = null, ActionResolver r3 = null, ActionResolver r4 = null, ActionResolver r5 = null, ActionResolver r6 = null, ActionResolver r7 = null, ActionResolver r8 = null, params ActionResolver[] remainder)
        {
            if (r1 != null) r1.DrawError();
            if (r2 != null) r2.DrawError();
            if (r3 != null) r3.DrawError();
            if (r4 != null) r4.DrawError();
            if (r5 != null) r5.DrawError();
            if (r6 != null) r6.DrawError();
            if (r7 != null) r7.DrawError();
            if (r8 != null) r8.DrawError();

            if (remainder != null)
            {
                for (int i = 0; i < remainder.Length; i++)
                {
                    if (remainder[i] != null)
                    {
                        remainder[i].DrawError();
                    }
                }
            }
        }
    }
}
#endif