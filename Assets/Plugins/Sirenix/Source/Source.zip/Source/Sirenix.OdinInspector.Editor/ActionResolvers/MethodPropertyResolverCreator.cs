#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="MethodPropertyResolverCreator.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Reflection;

[assembly: Sirenix.OdinInspector.Editor.ActionResolvers.RegisterDefaultActionResolver(typeof(Sirenix.OdinInspector.Editor.ActionResolvers.MethodPropertyResolverCreator), 20)]

namespace Sirenix.OdinInspector.Editor.ActionResolvers
{
#pragma warning disable

    public class MethodPropertyResolverCreator : ActionResolverCreator
    {
        public override string GetPossibleMatchesString(ref ActionResolverContext context)
        {
            return null;
        }

        public override ResolvedAction TryCreateAction(ref ActionResolverContext context)
        {
            var prop = context.Property;

            if (string.IsNullOrEmpty(context.ResolvedString) && prop.Info.PropertyType == PropertyType.Method)
            {
                MethodInfo method = (prop.Info.GetMemberInfo() as MethodInfo) ?? prop.Info.GetMethodDelegate().Method;

                NamedValues argSetup = default(NamedValues);

                if (IsCompatibleMethod(method, ref context.NamedValues, ref argSetup, out context.ErrorMessage))
                {
                    if (prop.Info.GetMethodDelegate() != null)
                    {
                        return GetDelegateInvoker(prop.Info.GetMethodDelegate(), argSetup);
                    }
                    else
                    {
                        return GetMethodInvoker((MethodInfo)prop.Info.GetMemberInfo(), argSetup, prop.ParentType.IsValueType);
                    }
                }
                else if (context.ErrorMessage != null)
                {
                    return FailedResolveAction;
                }
            }

            return null;
        }


    }
}
#endif